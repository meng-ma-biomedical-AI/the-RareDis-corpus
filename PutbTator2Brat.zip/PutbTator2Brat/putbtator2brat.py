#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 29 12:32:53 2021

@author: isegura

This file contains functions to use the Pubtator tool to annotate 
genes, diseases, chemicals, 


"""


import os

import glob
import re
from urllib.request import urlopen


def getPMID(nameFile):
    """This functions gets the name of a file, for example 3545087_XP.txt, and returns only its pmid"""
    try:
        sep=' '
        if '_' in nameFile:
            sep='_'
        pmid=nameFile[0:nameFile.index(sep)]   
        #print(nameFile,pmid)
    except:
        #some names of the files do not have ' ' or '_'
        match=re.search('[a-zA-Z]', nameFile)
        if match:
            sep=match.group()
            pmid=nameFile[0:nameFile.index(sep)]   
        else:
            print('Error processing ', nameFile)
            
    return pmid


def getListOfPMIDS(path_dir):
    """This function takes the path where the texts of the sample about skin rare diseases are stored
    and returns the list of their corresponding PMIDS. The ids are necessary as argument for the 
    PUBTATOR tool"""
    #print(glob.glob(path))#obtain the list of files but with full path
    
    list_files=list(map(os.path.basename, glob.glob(path_dir)))
    listOfIds=[getPMID(w) for w in list_files]   

    #print(listOfIds)
    
    return listOfIds



ENTITY_TYPES='gene,disease,chemical,mutation,species,cellline'


def runPubTator(pmid,dir_output,entity_types=ENTITY_TYPES):
    """This functions gets a pmid, runs the tool PubTator and then saves the annotations into a file.
    The funtions returns the name of the file """
    
    
    link_pubtator='https://www.ncbi.nlm.nih.gov/research/pubtator-api/publications/export/pubtator?pmids={}&concepts={}'.format(pmid,entity_types)

    #get the annotations created by pubtator
    f = urlopen(link_pubtator)
    data = f.read()
    txt = data.decode('utf-8')
    #print(txt)  
    f.close()

    #We now save the annotations into a file
    nameFile=dir_output+pmid+'.pub'
    fout = open(nameFile,'w')
    fout.write(txt)
    print('annotations by PUBTATOR were saved into ',nameFile)
    fout.close()
    
    return nameFile

def pubtator2brat(nameFile,dir_output):
    """This functions gets a file with Pubtator annotationes and creates its corresponding txt file and .ann file"""

    pmid=nameFile[nameFile.rindex('/')+1:nameFile.index('.')]
    print()
    print('converting from pubtator to brat', nameFile, pmid)
    
    fread = open(nameFile,'r')
    data = fread.readlines()
    fread.close()

    text_full=''
    
    anns=[]
    for i,line in enumerate(data):
        #print(i,line)
        if '|' in line:
            txt_line=line[line.rindex('|')+1:]
            #print(txt_line)
            text_full+=txt_line
        else:
            data_line=line.split('\t')
            if len(data_line)>1:
                anns.append(data_line[1:5])
                
        
        
    #print(text_full)
    ##saved into .txt
    newFiletxt=dir_output+pmid+'.txt'
    fout = open(newFiletxt,'w')
    fout.write(text_full)
    print('txt was saved into ',newFiletxt)
    fout.close()


    #print(anns)    
    newFileann=dir_output+pmid+'.ann'
    fout = open(newFileann,'w')
    for i,a in enumerate(anns):
        line_ann='T'+str(i+1)+'\t'+a[3].upper()+' '+a[0]+' '+a[1]+'\t'+a[2]+'\n'
        fout.write(line_ann)
    print('brat annotations was saved into ',newFileann)
    fout.close()

    
    
    
###main

if __name__ == '__main__':
    
    #path to store files with annotations created by pubtator 
    path_pubtator='skin-pubtator/'
    if not os.path.exists(path_pubtator):
        os.makedirs(path_pubtator)
        print("Directory " , path_pubtator ,  " Created ")
        
    #path to store files with annotations created by brat 
    path_brat='skin-brat/'
    if not os.path.exists(path_brat):
        os.makedirs(path_brat)
        print("Directory " , path_brat ,  " Created ")
        
    #path that contains the selection of abtracts about rare diseases
    path_input='input-texts/*.txt'
    #get the list of the pmids of these abstracts
    PMIDS=getListOfPMIDS(path_input)
    #print(PMIDS)
    for pmid in PMIDS:
        try:
            nameFile=runPubTator(pmid,path_pubtator)
            pubtator2brat(nameFile,path_brat)
        except:
            print('error processing:',pmid)