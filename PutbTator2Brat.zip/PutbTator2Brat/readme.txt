This contains a Python script, putbtator2brat.py, that reads txt files from a folder  (for example, the folder input_texts contains a sample of abstracts about skin rare diseases) and then uses the PubTator (https://www.ncbi.nlm.nih.gov/research/pubtator/) to annotate these text files. 
The entities annotated are: gene,disease,chemical,mutation,species,cellline. 
It is possible to choose a smaller set of entity types to be annotated.

Moreover, the scripts transforms the annotations from PubTator format (which are temporary saved into the folder skin-pubtator), to the brat format (which will be finally saved into the skin-brat folder)

Además el programa transforma las anotaciones del formato generado por PubTator, y que están almacenados en la carpeta skin-pubtator, al formato brat. Estas anotaciones se almacenan en la carpeta skin-brat. 

You should modify the file visual.conf of the brat annotation tool to choose those colors for the entity types annotated. 

It also contains a second script, statistics.py, that reads the ann files in the folder skin-brat, y counts the number of instances for each entity type annotated. 

For the set of input texts about skin rare diseases, the annotations are:

GENE 279
DISEASE 342
CHEMICAL 62
MUTATION 0
DNAMUTATION 3
PROTEINMUTATION 2
SPECIES 142
CELLLINE 4



