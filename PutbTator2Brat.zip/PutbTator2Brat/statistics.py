#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 29 15:26:39 2021

@author: isegura

This script cotains functions to obtain some statistics from annotations files

"""
import os
import glob




def getStatistics(nameFile,statistics):
    """This funcion takes an annotation, reads its annotations and increases 
    its corresponding the counter in the dictionary statistics"""
    
    #print('reading ', nameFile)
    f=open(nameFile,'r')
    lines=f.readlines()
    for line in lines:
        #print(line)
        line=line.strip()
        entity_type=line[line.index('\t')+1:line.index(' ')]
        #print(entity_type)
        try:
            statistics[entity_type]+=1
        except:
            print('error ', nameFile,entity_type)
            
    f.close()
    

if __name__ == '__main__':
    
    ENTITY_TYPES='gene,disease,chemical,mutation,dnamutation,proteinmutation,species,cellline'

    #This dictionary saves a key for each entity type and its corresponding value
    #that is the number of entities of this type in the dataset (path_brat)
    statistics={}
    for x in ENTITY_TYPES.split(','):
        statistics[x.upper()]=0
    
   #path that contains files with annotations created by brat 
    path_brat='skin-brat/'
    if not os.path.exists(path_brat):
        print("Directory " , path_brat ,  " does not exist!!!")
    
    else:
        path_brat+='*.ann'
        list_files=glob.glob(path_brat)
        for nameFile in list_files:
            getStatistics(nameFile,statistics)
            #break
        
        
    for entity_type in statistics.keys():
        print(entity_type,statistics[entity_type])